/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entities;

/**
 *
 * @author liz10
 */
public class EmptyRoom extends Entity {
    public EmptyRoom()
    {
        super(0,0,0,0,"There is nothing in here...");//HP, ATTACK, DEFENSE, SPEED
    }
}
